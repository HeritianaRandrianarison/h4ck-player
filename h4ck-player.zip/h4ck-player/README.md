# H4CK//PLAYER

Lecteur audio/vidéo hacker avec terminal et visualiseur 3D (Capacitor + Three.js).

## Obtenir l'APK
1. Crée un dépôt GitHub et pousse ce dossier sur la branche `main`.
2. Onglet **Actions** : le build se lance tout seul (~5 min).
3. Télécharge `h4ck-player.apk` dans **Releases** (ou dans les artefacts du run).
4. Installe-le sur le téléphone (autorise les sources inconnues).

## Commandes du terminal
Tape `help` dans l'app. Essaie `add`, `ls`, `play 1`, `video 2`, `theme cyan`, `hack`.
