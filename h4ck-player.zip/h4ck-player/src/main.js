import * as THREE from 'three';
import './style.css';

const $ = s => document.querySelector(s);
const THEMES = { green: '#00ff9c', cyan: '#00e5ff', red: '#ff2d55', amber: '#ffb000' };
const PS1 = 'root@h4ck:~#';
const out = $('#out'), inp = $('#in'), video = $('#video'), fileEl = $('#file'), audio = new Audio();
let lib = [], cur = -1, shuf = false, rep = false, hist = [], hi = 0, rain = true, boost = 0, color = THEMES.green;
const t0 = Date.now();
const sleep = ms => new Promise(r => setTimeout(r, ms));
const fmt = s => isFinite(s) ? String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(Math.floor(s % 60)).padStart(2, '0') : '00:00';
$('#ps1').textContent = PS1;

/* ---------- terminal output ---------- */
function print(t, c = '') {
  const d = document.createElement('div'); d.className = c; d.textContent = t; out.appendChild(d);
  while (out.children.length > 300) out.firstChild.remove();
  out.scrollTop = out.scrollHeight; return d;
}
const err = t => print('✖ ' + t, 'err');
async function type(t, c = '', ms = 12) {
  const d = print('', c);
  for (const ch of t) { d.textContent += ch; await sleep(ms); }
  out.scrollTop = out.scrollHeight;
}

/* ---------- audio / video engine ---------- */
let ctx, analyser; const fd = new Uint8Array(64);
const el = () => (lib[cur] && lib[cur].video ? video : audio);
function initAudio() {
  if (ctx) return;
  ctx = new (window.AudioContext || window.webkitAudioContext)();
  analyser = ctx.createAnalyser(); analyser.fftSize = 128; analyser.smoothingTimeConstant = 0.8;
  for (const m of [audio, video]) ctx.createMediaElementSource(m).connect(analyser);
  analyser.connect(ctx.destination);
}
function playIdx(i) {
  const t = lib[i];
  if (!t) return err('piste introuvable');
  initAudio(); ctx.resume(); cur = i; boost = 0.6;
  audio.pause(); video.pause();
  (t.video ? audio : video).removeAttribute('src');
  video.classList.toggle('show', t.video);
  const m = t.video ? video : audio;
  m.src = t.url;
  m.play().catch(e => err(e.message));
  $('#np').textContent = '▶ ' + t.name;
  print(`▶ [${i + 1}] ${t.name}${t.video ? ' (vidéo)' : ''}`, 'ok');
}
function find(a) {
  if (!lib.length) { err("bibliothèque vide : tape 'add'"); return -1; }
  if (/^\d+$/.test(a)) { const i = +a - 1; if (lib[i]) return i; err('index invalide'); return -1; }
  const i = lib.findIndex(t => t.name.toLowerCase().includes(a.toLowerCase()));
  if (i < 0) err('aucun résultat pour "' + a + '"');
  return i;
}
function next() {
  if (!lib.length) return err('bibliothèque vide');
  playIdx(shuf ? Math.floor(Math.random() * lib.length) : (cur + 1) % lib.length);
}
function upd() {
  const m = el();
  $('#fill').style.width = (m.duration ? (m.currentTime / m.duration) * 100 : 0) + '%';
  $('#time').textContent = fmt(m.currentTime) + ' / ' + fmt(m.duration);
}
for (const m of [audio, video]) {
  m.addEventListener('timeupdate', upd);
  m.addEventListener('loadedmetadata', upd);
  m.addEventListener('ended', () => (rep ? playIdx(cur) : next()));
}
$('#bar').onclick = e => {
  const m = el(), r = e.currentTarget.getBoundingClientRect();
  if (m.duration) m.currentTime = ((e.clientX - r.left) / r.width) * m.duration;
};
fileEl.onchange = () => {
  const n = lib.length;
  for (const f of fileEl.files) {
    lib.push({
      name: f.name.replace(/\.[^.]+$/, ''), url: URL.createObjectURL(f),
      video: f.type.startsWith('video') || /\.(mp4|mkv|webm|3gp|mov)$/i.test(f.name),
    });
  }
  fileEl.value = '';
  print(`+ ${lib.length - n} fichier(s) chargé(s). tape 'ls'`, 'ok');
};

/* ---------- theme ---------- */
const mats = [];
function setTheme(n) {
  if (!THEMES[n]) return err('thèmes : ' + Object.keys(THEMES).join(', '));
  color = THEMES[n];
  document.documentElement.style.setProperty('--c', color);
  mats.forEach(m => m.color.set(color));
  print('thème → ' + n, 'ok');
}

/* ---------- commands ---------- */
const C = {
  help() {
    print(`ls · add · play [n|nom] · video [n|nom]
pause · resume · stop · next · prev
seek [+/-]sec · vol 0-100 · shuffle · repeat
theme green|cyan|red|amber · matrix on|off
neofetch · hack · history · clear · date · echo · whoami`, 'ok');
  },
  ls() {
    if (!lib.length) return print("(vide) tape 'add' pour choisir des fichiers", 'dim');
    lib.forEach((t, i) => print(`${i === cur ? '▶' : ' '} ${String(i + 1).padStart(2, '0')}  ${t.name}${t.video ? '  [VID]' : ''}`));
  },
  add() { fileEl.click(); },
  play(a) {
    if (!a) { if (cur < 0) return err('rien à lire'); initAudio(); ctx.resume(); return void el().play(); }
    const i = find(a); if (i >= 0) playIdx(i);
  },
  video(a) {
    const i = find(a || '1'); if (i < 0) return;
    if (!lib[i].video) return err("ce fichier est audio : utilise 'play'");
    playIdx(i);
  },
  pause() { el().pause(); print('⏸ pause', 'dim'); },
  resume() { C.play(''); },
  toggle() { el().paused ? C.play('') : C.pause(); },
  stop() { audio.pause(); video.pause(); video.classList.remove('show'); audio.currentTime = 0; $('#np').textContent = 'NO SIGNAL'; print('■ stop', 'dim'); },
  next, prev() {
    if (!lib.length) return err('bibliothèque vide');
    if (el().currentTime > 3) el().currentTime = 0; else playIdx((cur - 1 + lib.length) % lib.length);
  },
  seek(a) {
    const n = parseFloat(a); if (isNaN(n)) return err('seek +10 | seek -10 | seek 90');
    if (/^[+-]/.test(a)) el().currentTime += n; else el().currentTime = n;
  },
  vol(a) {
    const n = parseInt(a); if (isNaN(n)) return print('volume : ' + Math.round(audio.volume * 100), 'dim');
    audio.volume = video.volume = Math.min(100, Math.max(0, n)) / 100; print('volume → ' + n, 'dim');
  },
  shuffle() { shuf = !shuf; print('shuffle ' + (shuf ? 'ON' : 'OFF'), 'dim'); },
  repeat() { rep = !rep; print('repeat ' + (rep ? 'ON' : 'OFF'), 'dim'); },
  theme(a) { setTheme(a); },
  matrix(a) { rain = a !== 'off'; print('matrix ' + (rain ? 'ON' : 'OFF'), 'dim'); },
  clear() { out.innerHTML = ''; },
  history() { hist.forEach((h, i) => print(` ${i + 1}  ${h}`, 'dim')); },
  date() { print(new Date().toString(), 'dim'); },
  echo(a) { print(a); },
  whoami() { print('root (enfin, presque)', 'dim'); },
  sudo() { err('root is not in the sudoers file. This incident will be reported.'); boost = 1; },
  neofetch() {
    const up = Math.floor((Date.now() - t0) / 1000);
    print(`   ▄▄▄▄▄▄▄     root@h4ck
  █ ▀▄▄▄▀ █    ─────────
  █  ▀▀▀  █    OS: H4CK//OS 1.0
  █▄▄▄▄▄▄▄█    Kernel: android-webview
  ▀▀▀▀▀▀▀▀▀    Uptime: ${up}s
               Pistes: ${lib.length}
               Thème: ${color}
               Écran: ${innerWidth}x${innerHeight}`, 'ok');
  },
  async hack() {
    boost = 1;
    for (const l of ['nmap -sS 10.0.0.0/24', '[+] 22/tcp open ssh', '[+] 443/tcp open https', 'bruteforce --target root ...', 'injecting payload 0x' + Math.random().toString(16).slice(2, 10)]) {
      await type('> ' + l, 'dim', 8); await sleep(180);
    }
    const bar = print('');
    for (let i = 0; i <= 24; i++) { bar.textContent = '[' + '█'.repeat(i) + '░'.repeat(24 - i) + '] ' + Math.round((i / 24) * 100) + '%'; boost = 1.5; await sleep(60); }
    $('#app').classList.add('shake'); await sleep(700); $('#app').classList.remove('shake');
    print('ACCESS GRANTED', 'ok'); boost = 2;
  },
};
async function run(line) {
  print(PS1 + ' ' + line, 'dim');
  hist.push(line); hi = hist.length;
  const [cmd, ...rest] = line.split(/\s+/);
  const a = rest.join(' ');
  if (line.includes('rm -rf')) { await type('rm: suppression de / ... (je rigole)', 'err', 15); boost = 2; return; }
  const f = C[cmd];
  if (f) await f(a); else err(cmd + ': commande introuvable');
}
function complete() {
  const v = inp.value;
  if (!v.includes(' ')) {
    const m = Object.keys(C).filter(n => n.startsWith(v));
    if (m.length === 1) inp.value = m[0] + ' '; else if (m.length > 1) print(m.join('  '), 'dim');
  } else if (v.startsWith('theme ')) {
    const m = Object.keys(THEMES).filter(n => n.startsWith(v.slice(6)));
    if (m.length === 1) inp.value = 'theme ' + m[0];
  }
}
inp.addEventListener('keydown', e => {
  if (e.key === 'Enter') { const v = inp.value.trim(); inp.value = ''; if (v) run(v); }
  else if (e.key === 'Tab') { e.preventDefault(); complete(); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); if (hi > 0) hi--; inp.value = hist[hi] || ''; }
  else if (e.key === 'ArrowDown') { e.preventDefault(); if (hi < hist.length - 1) { hi++; inp.value = hist[hi]; } else { hi = hist.length; inp.value = ''; } }
});
document.querySelectorAll('nav button').forEach(b => b.onclick = () => (b.dataset.c === 'tab' ? complete() : C[b.dataset.c]()));
$('#term').addEventListener('click', () => inp.focus());
setInterval(() => ($('#clock').textContent = new Date().toTimeString().slice(0, 8)), 1000);

/* ---------- matrix rain (2D) ---------- */
const rc = $('#rain'), rx = rc.getContext('2d');
const chars = '01アイウエオカキクケコサシスセソ<>/{}$#';
let drops = [], last = 0;
function rainFrame(ts) {
  if (!rain) { rx.clearRect(0, 0, rc.width, rc.height); return; }
  if (ts - last < 55) return; last = ts;
  rx.fillStyle = 'rgba(0,0,0,.12)'; rx.fillRect(0, 0, rc.width, rc.height);
  rx.fillStyle = color; rx.font = '14px monospace';
  drops.forEach((y, i) => {
    rx.fillText(chars[(Math.random() * chars.length) | 0], i * 14, y * 14);
    drops[i] = y * 14 > rc.height && Math.random() > 0.975 ? 0 : y + 1;
  });
}

/* ---------- 3D scene ---------- */
const renderer = new THREE.WebGLRenderer({ canvas: $('#gl'), alpha: true, antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
const scene = new THREE.Scene(), cam = new THREE.PerspectiveCamera(60, 1, 0.1, 100);
cam.position.set(0, 1.5, 9);
const mk = (M, o) => { const m = new M({ color, transparent: true, ...o }); mats.push(m); return m; };
const group = new THREE.Group(); group.rotation.x = 0.35; scene.add(group);
const N = 64, bars = [], bg = new THREE.BoxGeometry(0.12, 1, 0.12), bm = mk(THREE.MeshBasicMaterial, { opacity: 0.9 });
for (let i = 0; i < N; i++) {
  const a = (i / N) * Math.PI * 2, b = new THREE.Mesh(bg, bm);
  b.position.set(Math.cos(a) * 3.2, 0, Math.sin(a) * 3.2); b.rotation.y = -a; group.add(b); bars.push(b);
}
const core = new THREE.Mesh(new THREE.IcosahedronGeometry(1.4, 2), mk(THREE.MeshBasicMaterial, { wireframe: true, opacity: 0.8 }));
group.add(core);
const pp = new Float32Array(1800 * 3);
for (let i = 0; i < 1800; i++) {
  const r = 5 + Math.random() * 6, th = Math.random() * 6.283, ph = Math.acos(2 * Math.random() - 1);
  pp.set([r * Math.sin(ph) * Math.cos(th), r * Math.sin(ph) * Math.sin(th), r * Math.cos(ph)], i * 3);
}
const pg = new THREE.BufferGeometry(); pg.setAttribute('position', new THREE.BufferAttribute(pp, 3));
const pts = new THREE.Points(pg, mk(THREE.PointsMaterial, { size: 0.05, opacity: 0.8 })); scene.add(pts);
const grid = new THREE.GridHelper(40, 40, 0xffffff, 0xffffff); grid.position.y = -3.5;
grid.material.transparent = true; grid.material.opacity = 0.25; mats.push(grid.material); scene.add(grid);
mats.forEach(m => m.color.set(color));

function resize() {
  const w = innerWidth, h = innerHeight;
  renderer.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix();
  rc.width = w; rc.height = h; drops = Array.from({ length: Math.floor(w / 14) }, () => Math.random() * -50);
}
addEventListener('resize', resize); resize();

function loop(ts) {
  requestAnimationFrame(loop);
  const t = (Date.now() - t0) / 1000;
  if (analyser && !el().paused) analyser.getByteFrequencyData(fd);
  else for (let i = 0; i < 64; i++) fd[i] = 40 + 30 * Math.sin(t * 2 + i * 0.3);
  let bass = 0; for (let i = 0; i < 6; i++) bass += fd[i]; bass /= 6 * 255;
  bars.forEach((b, i) => { const h = 0.15 + (fd[i] / 255) * 3.2; b.scale.y += (h - b.scale.y) * 0.35; b.position.y = b.scale.y / 2; });
  core.scale.setScalar(1 + bass * 0.6); core.rotation.x += 0.004 + bass * 0.02; core.rotation.y += 0.006 + bass * 0.02;
  group.rotation.y += 0.004 + boost * 0.08 + bass * 0.01;
  pts.rotation.y -= 0.0008 + boost * 0.01;
  grid.position.z = t % 1;
  cam.position.x = (Math.random() - 0.5) * boost * 0.4;
  boost *= 0.95; if (boost < 0.01) boost = 0;
  renderer.render(scene, cam); rainFrame(ts);
}
requestAnimationFrame(loop);

/* ---------- boot ---------- */
(async () => {
  for (const l of ['H4CK//OS v1.0 — boot', '[ OK ] mount /sdcard/media', '[ OK ] load audio.kernel', '[ OK ] init webgl.core', '[ OK ] spawn visualizer', '', "tape 'help' · 'add' pour charger des fichiers"]) {
    await type(l, l.includes('OK') ? 'ok' : 'dim', 10); await sleep(90);
  }
  boost = 1.2;
})();
