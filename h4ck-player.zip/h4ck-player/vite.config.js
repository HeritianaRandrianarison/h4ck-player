export default { base: './' };
